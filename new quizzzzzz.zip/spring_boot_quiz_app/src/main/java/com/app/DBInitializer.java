package com.app;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.app.model.Quiz;
import com.app.service.QuizService;

@Component
public class DBInitializer implements CommandLineRunner{
	private QuizService service;
	public DBInitializer(QuizService service) {
		this.service=service;
	}
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Quiz quiz1 =new Quiz("“How many states make up the United States of America?","30" ," 50 "," 25 "," 52 ",2);
		Quiz quiz2 =new Quiz("H2O is the chemical formula for what?","Acid ","Petrol","Diesel","Water",4);
		Quiz quiz3 = new Quiz("Complete the title of the play by Shakespeare – ‘The Merchant of …’?","Menice"," Dennis","vinnce ", "Venice",4);
		Quiz quiz4=new Quiz( "By what name is the TV adventurer Edward Michael Grylls more commonly known?",  "Bear Grylls "," Joseph", "Johnny", " All the above", 1);
		Quiz quiz5=new Quiz( "Which is the country with the biggest population in Europe?","Russia","America", " Italy", " France",  1);
		Quiz quiz6=new Quiz( "What type of creature lives in an apiary?", "Flies", "Bee", " Mosquitoes","Ant", 2);
		Quiz quiz7=new Quiz("Which is the world’s largest flower?", "Lilly ", "Rose ","Rafflesia", "Sunflower ",  3);
		Quiz quiz8=new Quiz("Which is the longest river on the earth?", " Yamuna", "Godavari", "Krishna", "Nile", 4);
		Quiz quiz9=new Quiz("Who is the inventor of Radio?  ", "Einstein ", "Newton", "Gallileo", "Marconi", 4);
		Quiz quiz10=new Quiz("Which gas is most abundant in the earth’s atmosphere?", "Oxygen ", "Nitrogen ", "Carbon Dioxide", "Ammonia ", 2);
		this.service.saveQuiz(quiz1);
		this.service.saveQuiz(quiz2);
		this.service.saveQuiz(quiz3);
		this.service.saveQuiz(quiz4);
		this.service.saveQuiz(quiz5);
		this.service.saveQuiz(quiz6);
		this.service.saveQuiz(quiz7);
		this.service.saveQuiz(quiz8);
		this.service.saveQuiz(quiz9);
		this.service.saveQuiz(quiz10);
		System.out.println("Database has been initialized");
		
	}

}
